//
//  Favourit_places_m1_Tests.swift
//  Favourit-places(m1)Tests
//
//  Created by Sam on 8/4/19.
//  Copyright © 2019 Sam. All rights reserved.
//

import XCTest
@testable import Favourit_places_m1_

class Favourit_places_m1_Tests: XCTestCase {

    override func setUp() {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        
    }
    func teststruct() {
        let a = "Brisbane"
        let b = "queensland"
        let c = "10.0"
        let d = "-123.123"
        let test1 = FavPlaces(name: a, address: b, longitute: c, latitute: d)
        XCTAssertEqual(test1.name, a)
        XCTAssertEqual(test1.address, b)
        XCTAssertEqual(test1.longitute, c)
        XCTAssertEqual(test1.latitute, d)
    }
    
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
