//
//  DetailViewController.swift
//  Favourit-places(m1)
//
//  Created by Sam on 8/4/19.
//  Copyright © 2019 Sam. All rights reserved.
//

import UIKit

class DetailViewController: UITableViewController, UITextFieldDelegate {

    
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var address: UITextField!
    @IBOutlet weak var latitute: UITextField!
    @IBOutlet weak var longitute: UITextField!
    
    
    
    weak internal var delegate: DataDelegation?
    
    var place = FavPlaces ()
    var index : Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        name.text = place.name
        address.text = place.address
        latitute.text = place.latitute
        longitute.text = place.longitute
    }
    
    
    
    /// add values through a delegate
    ///
    /// - Parameter animated: if true
    override func viewDidDisappear(_ animated: Bool) {
        
        if self.delegate != nil && checkData() {
            
            place.name = name.text!
            place.address = address.text!
            place.latitute = latitute.text!
            place.longitute = longitute.text!
            
            if index == nil {
                
                self.delegate?.passdata(location: place)
                
            }else{
                
                self.delegate?.passdata(location: place, index: index)
            }
            
            
        }
        
    }
    
    /// check if the name textField is empty
    ///
    /// - Returns: returns True or False
    func checkData() -> Bool{
        
        if name.text == "" {
            
            return false
        }
        else {
            
            return true
        }
        
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        if textField.tag == 3 || textField.tag == 4 {
            
            backbutton(textField)
        }
    }
    
    /// Create a button back to master
    ///
    /// - Parameter textField: barr button
    func backbutton(_ textField: UITextField)
    {
        let toolBar = UIToolbar(frame: CGRect(x: 0,y: 0,width: self.view.frame.size.width, height: 44))
        toolBar.backgroundColor = UIColor.darkGray
        toolBar.tintColor = UIColor.black
        let barbuttonDone : UIBarButtonItem = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(self.click_DonePicker(_:)))
        toolBar.items = [barbuttonDone]
        barbuttonDone.tag = textField.tag
        textField.inputAccessoryView = toolBar
    }
    
    @objc func click_DonePicker(_ sender : UIBarButtonItem){
        
        self.view.endEditing(true)
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        let nextTag: Int = textField.tag + 1
        let nextResponder = textField.superview?.viewWithTag(nextTag) as UIResponder?
        if (nextResponder != nil)  {
            nextResponder?.becomeFirstResponder()
        }
        else {
            textField.resignFirstResponder()
        }
        return true
    }
 
}
