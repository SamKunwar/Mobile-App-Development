//
//  classes.swift
//  Favourit-places(m1)
//
//  Created by Sam on 8/4/19.
//  Copyright © 2019 Sam. All rights reserved.
//

import Foundation
import UIKit

class FavouritPlaces{
    var Name : String
    var Address : String
    var Longitute : Int
    var Latitute : Int
    
    init (Name: String, Address: String, Longitute: Int, Latitute: Int){
        self.Name = Name
        self.Address = Address
        self.Longitute = Longitute
        self.Latitute = Latitute
    }
}

protocol DataDelegate {
    func passdata(data: [String])
}
