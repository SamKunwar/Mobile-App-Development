//
//  MasterViewController.swift
//  Favourit-places(m1)
//
//  Created by Sam on 8/4/19.
//  Copyright © 2019 Sam. All rights reserved.
//

import UIKit

class MasterViewController: UITableViewController{

    var controller = DetailViewController()
    var locations = [FavPlaces]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       navigationItem.leftBarButtonItem = editButtonItem
        
        let addButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addData))
        navigationItem.rightBarButtonItem = addButton
        
        tableView.tableFooterView = UIView()
    }
    
 
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
    }
    
    @objc func addData(_ sender: Any) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        vc.delegate = self
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return locations.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "listcell", for: indexPath)
        
        let name = locations[indexPath.row].name
        cell.textLabel!.text = name
        return cell
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        vc.place = locations[indexPath.row]
        vc.index = indexPath.row
        vc.delegate = self
        self.navigationController?.pushViewController(vc, animated: true)
        
    }

    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        locations.remove(at: indexPath.row)
        tableView.deleteRows(at: [indexPath], with: .fade)
        tableView.reloadData()
    }
    override func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndesPath: IndexPath){
        let movedObjTemp = locations[sourceIndexPath.item]
        locations.remove(at: sourceIndexPath.item)
        locations.insert(movedObjTemp, at: destinationIndesPath.item)
    }
}


extension MasterViewController: DataDelegation{
    
    func passdata(location: FavPlaces, index: Int) {
        locations[index] = location
        tableView.reloadData()
    }
    func passdata(location: FavPlaces) {
        locations.append(location)
        tableView.reloadData()
    }
    
}
