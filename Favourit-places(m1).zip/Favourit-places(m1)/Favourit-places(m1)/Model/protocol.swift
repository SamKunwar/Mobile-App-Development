//
//  protocol.swift
//  Favourit-places(m1)
//
//  Created by Sam on 9/4/19.
//  Copyright © 2019 Sam. All rights reserved.
//

import Foundation
import UIKit

/// declaration of delegates to pass value through viewcontroller
protocol DataDelegation : NSObjectProtocol {
    
    func passdata(location:FavPlaces, index:Int)
    func passdata(location:FavPlaces)
    
}
