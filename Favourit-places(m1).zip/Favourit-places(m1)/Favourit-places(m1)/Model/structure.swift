//
//  structure.swift
//  Favourit-places(m1)
//
//  Created by Sam on 9/4/19.
//  Copyright © 2019 Sam. All rights reserved.
//

import Foundation
import UIKit

/// class to assign user input
struct FavPlaces{
    var name: String
    var address: String
    var longitute: String
    var latitute: String

    init(){
        self.name = ""
        self.address = ""
        self.longitute = ""
        self.latitute = ""
    }
    
    /// initial method
    ///
    /// - Parameters:
    ///   - name: name of the place
    ///   - address: address of the place
    ///   - longitute: longitute
    ///   - latitute: latitute
    init (name: String, address: String,longitute: String, latitute: String){
        self.name = name
        self.address = address
        self.longitute = longitute
        self.latitute = latitute
    }
}
