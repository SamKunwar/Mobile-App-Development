//
//  Favourit_places_m1_UITests.swift
//  Favourit-places(m1)UITests
//
//  Created by Sam on 8/4/19.
//  Copyright © 2019 Sam. All rights reserved.
//

import XCTest

class Favourit_places_m1_UITests: XCTestCase {

    override func setUp() {
        // Put setup code here. This method is called before the invocation of each test method in the class.

        // In UI tests it is usually best to stop immediately when a failure occurs.
        continueAfterFailure = false

        // UI tests must launch the application that they test. Doing this in setup will make sure it happens for each test method.
        XCUIApplication().launch()

        // In UI tests it’s important to set the initial state - such as interface orientation - required for your tests before they run. The setUp method is a good place to do this.
    }

    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() {
        // Use recording to get started writing UI tests.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        
        let app = XCUIApplication()
        app.otherElements.containing(.navigationBar, identifier:"Master").children(matching: .other).element.children(matching: .other).element.children(matching: .table).element.swipeDown()
        
        let masterNavigationBar = app.navigationBars["Master"]
        let editButton = masterNavigationBar.buttons["Edit"]
        editButton.tap()
        
        let doneButton = masterNavigationBar.buttons["Done"]
        doneButton.tap()
        
        let tablesQuery = app.tables
        let brisbaneStaticText = tablesQuery/*@START_MENU_TOKEN@*/.staticTexts["Brisbane"]/*[[".cells.staticTexts[\"Brisbane\"]",".staticTexts[\"Brisbane\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/
        brisbaneStaticText.swipeLeft()
        brisbaneStaticText.swipeRight()
        editButton.tap()
        tablesQuery/*@START_MENU_TOKEN@*/.buttons["Reorder Brisbane"]/*[[".cells.buttons[\"Reorder Brisbane\"]",".buttons[\"Reorder Brisbane\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.swipeDown()
        doneButton.tap()
        brisbaneStaticText.tap()
        tablesQuery.cells.containing(.staticText, identifier:"Name:").children(matching: .textField).element.tap()
        app.navigationBars["Detail"].buttons["Master"].tap()
                
    }
    func test2() {
        
    }

}
